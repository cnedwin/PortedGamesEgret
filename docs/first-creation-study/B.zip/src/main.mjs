import { play } from '@egret/engine/play';
import { boardGuest, beginWorld, buildCost, buildShed, firstFare, PLOTS } from './sim/world.mjs';
import { readProgress, SAVE_KEY, writeProgress } from './saves.mjs';
import { boatArt, personArt, shedArt, terrain } from './scenery.mjs';

const el = id => document.getElementById(id);
const boxes = new Map();
const art = {};
const steps = [...document.querySelectorAll('.steps li')];
const focus = node => node.focus({ preventScroll: true });
const at = (x, y) => ({ x, y });
const wait = at(481, 418);
const pier = at(447, 394);
const ramp = at(491, 351);
const homeWater = at(533, 343);
const farWater = at(795, 229);
const farPier = at(817, 210);
const farPath = at(834, 186);
const frameTime = 1.05;
const tripTime = 5.3;
let world = beginWorld();
let muted = false;
let game;
let closed = false;
let resetting = false;
let building = null;
let crossing = 0;

function mix(a, b, t) {
  const u = Math.max(0, Math.min(t, 1));
  return at(a.x + (b.x - a.x) * u, a.y + (b.y - a.y) * u);
}

function save() {
  try { writeProgress(game, world, muted); } catch { /* Keep the current session playable. */ }
}

function view() {
  if (resetting) return ['重开渡口？', '本轮搭好的船棚会收起，木料与账目将恢复到开局。', '确认重开', '返回'];
  if (world.trip === 'arrived') return ['第一趟，平安到岸', `客人已经走上北岸，付了 ${firstFare} 枚铜钱。${world.shed.name}的船棚也有了第一道灯火。`];
  if (world.trip === 'sailing') return ['船过春水', '摆渡人接客上船，正划向北岸的石埠。'];
  if (building !== null) return ['木梁立起来了', `摆渡人正在${world.shed.name}搭棚，好让渡船靠岸时有处遮雨。`];
  if (world.shed) return ['接第一位客人', `船棚已在${world.shed.name}搭好。客人在南岸木埠等船，要去对岸的村子。`, '接客开船'];
  if (world.selected) return [`在${world.selected.name}搭棚`, `${world.selected.note}用 ${buildCost} 份木料。可以改选，也可以取消。`, `动工 · ${buildCost} 木料`, '取消'];
  return ['给摆渡人搭座船棚', '船已靠岸，客人也到了。点选岸边的一处用地，先给摆渡人搭一座船棚。'];
}

function refresh() {
  const [title, hint, action, cancel] = view();
  const arrived = world.trip === 'arrived';
  const ready = world.shed && building === null;
  const count = arrived ? 3 : ready ? 2 : world.shed || world.selected ? 1 : 0;
  el('objective').textContent = title;
  el('hint').textContent = hint;
  el('timber').textContent = 12 - (world.shed ? buildCost : 0);
  el('fare').textContent = arrived ? firstFare : 0;
  el('people').textContent = arrived ? 1 : 0;
  el('progress').textContent = `${count} / 3`;
  el('river-status').textContent = arrived ? '渡船已到北岸' : world.trip === 'sailing' ? '渡船正在横渡' : '渡船系在南岸';
  el('sites').hidden = Boolean(world.shed);
  el('landing').hidden = world.trip !== 'waiting';
  el('guest').disabled = !ready;
  el('guest').textContent = ready ? '接客开船' : '等船客人';
  for (const [plot, button] of boxes) button.setAttribute('aria-pressed', String(plot === world.selected));
  for (const [i, step] of steps.entries()) {
    step.classList.toggle('done', i < count);
    step.firstElementChild.textContent = i < count ? '✓' : '';
    if (i === count) step.setAttribute('aria-current', 'step');
    else step.removeAttribute('aria-current');
  }
  el('confirm').hidden = !action;
  el('confirm').textContent = action ?? '';
  el('cancel').hidden = !cancel;
  el('cancel').textContent = cancel ?? '';
  el('again').hidden = !arrived || resetting;
  el('sound').textContent = `声音：${muted ? '关' : '开'}`;
  el('sound').setAttribute('aria-pressed', String(!muted));
}

function draw(time = 0) {
  const plot = world.shed ?? world.selected;
  for (const [item, visible] of [[art.preview, Boolean(world.selected)], [art.frame, building !== null], [art.shed, Boolean(world.shed) && building === null]]) {
    item.visible = visible;
    if (plot) { item.x = plot.x; item.y = plot.y; }
  }
  const arrived = world.trip === 'arrived';
  const sailing = world.trip === 'sailing';
  const motion = !game?.reducedMotion;
  const t = arrived ? tripTime : crossing;
  const afloat = mix(homeWater, farWater, (t - 1.3) / 2.95);
  if (sailing && t > 1.3 && t < 4.25) afloat.y -= Math.sin(Math.PI * (t - 1.3) / 2.95) * 19;
  afloat.y += motion && game ? Math.sin(time * 2.4) * 1.2 : 0;
  art.boat.x = afloat.x;
  art.boat.y = afloat.y;
  art.wake.x = afloat.x;
  art.wake.y = afloat.y;
  art.wake.visible = sailing && t > 1.3 && t < 4.25;

  const onBoat = at(afloat.x - 33, afloat.y - 8);
  const offBoat = at(afloat.x + 33, afloat.y - 9);
  let guest = wait;
  let ferryman = at(463, 380);
  if (world.shed) ferryman = building === null ? at(plot.x + 40, plot.y + 7) : mix(ferryman, at(plot.x + 40, plot.y + 7), building / frameTime);
  if (sailing || arrived) {
    const board = at(homeWater.x - 33, homeWater.y - 8);
    if (t < .52) {
      guest = mix(wait, pier, t / .52);
      ferryman = mix(ferryman, pier, t / .52);
    } else if (t < 1.3) {
      const dockWalk = mix(pier, ramp, (t - .52) / .62);
      guest = t < 1.14 ? dockWalk : mix(ramp, board, (t - 1.14) / .16);
      ferryman = t < 1.14 ? mix(pier, ramp, (t - .52) / .54) : mix(ramp, offBoat, (t - 1.14) / .16);
    } else {
      ferryman = offBoat;
      guest = t < 4.25 ? onBoat : t < 4.73 ? mix(onBoat, farPier, (t - 4.25) / .48) : mix(farPier, farPath, (t - 4.73) / (tripTime - 4.73));
    }
  }
  art.guest.x = guest.x;
  art.guest.y = guest.y;
  art.ferryman.x = ferryman.x;
  art.ferryman.y = ferryman.y;
}

function launch() {
  if (!game || building !== null || !boardGuest(world)) return;
  crossing = 0;
  if (game.reducedMotion) {
    arrive(true);
    return;
  }
  save();
  game.sfx.play('castoff', { volume: .48 });
  draw();
  refresh();
}

function arrive(moveFocus) {
  world.trip = 'arrived';
  save();
  game.sfx.play('coin', { volume: .32 });
  draw();
  refresh();
  if (moveFocus || document.activeElement === document.body) focus(el('again'));
}

function cancel() {
  const selected = world.selected;
  world.selected = null;
  const wasResetting = resetting;
  resetting = false;
  draw();
  refresh();
  if (wasResetting) focus(el('again'));
  else if (selected) focus(boxes.get(selected));
}

function confirm() {
  if (!game) return;
  if (resetting) {
    resetting = false;
    world = beginWorld();
    crossing = 0;
    save();
    draw();
    refresh();
    focus(boxes.get(PLOTS[0]));
    return;
  }
  if (world.shed) { launch(); return; }
  if (!buildShed(world)) return;
  building = game.reducedMotion ? null : 0;
  save();
  game.sfx.play('build', { volume: .55 });
  draw();
  refresh();
  if (building === null) focus(el('confirm'));
}

for (const plot of PLOTS) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'plot';
  button.style.left = `${plot.x / 960 * 100}%`;
  button.style.top = `${plot.y / 540 * 100}%`;
  button.setAttribute('aria-label', `预览${plot.name}船棚`);
  const marker = document.createElement('span');
  marker.className = 'marker';
  marker.setAttribute('aria-hidden', 'true');
  const label = document.createElement('span');
  label.className = 'name';
  label.textContent = plot.name;
  button.append(marker, label);
  boxes.set(plot, button);
  el('sites').append(button);
  button.addEventListener('click', () => {
    if (!game || world.shed) return;
    world.selected = plot;
    game.sfx.play('click', { volume: .26 });
    draw();
    refresh();
    focus(el('confirm'));
  });
}

el('confirm').addEventListener('click', confirm);
el('cancel').addEventListener('click', cancel);
el('guest').addEventListener('click', launch);
el('again').addEventListener('click', () => {
  resetting = true;
  refresh();
  focus(el('cancel'));
});
el('sound').addEventListener('click', () => {
  muted = !muted;
  game.sfx.muted = muted;
  save();
  refresh();
});
el('village').addEventListener('keydown', event => {
  if (event.key === 'Escape' && (world.selected || resetting)) {
    event.preventDefault();
    cancel();
  }
});
window.addEventListener('pagehide', event => {
  if (event.persisted) return;
  closed = true;
  if (game) void game.dispose();
});

try {
  const player = await play({
    parent: el('surface'), width: 960, height: 540, saveKey: SAVE_KEY,
    setup(g) {
      let saved;
      try { saved = readProgress(g); } catch { saved = null; }
      muted = saved?.muted === true;
      world = beginWorld(saved);
      g.sfx.muted = muted;
      g.sfx.define('build', [
        { wave: 'triangle', from: 157, to: 83, seconds: .12, decay: 7 },
        { wave: 'sine', from: 490, to: 540, seconds: .19, decay: 5 }
      ]);
      g.sfx.define('castoff', { wave: 'sine', from: 223, to: 326, seconds: .25, decay: 5 });
      terrain(g, PLOTS);
      art.preview = shedArt(g, 'preview');
      art.preview.alpha = .68;
      art.frame = shedArt(g, 'frame');
      art.shed = shedArt(g, 'ready');
      Object.assign(art, boatArt(g));
      art.guest = personArt(g, 0xa8503c, 0x754d3a);
      art.ferryman = personArt(g, 0x405f66, 0xbd9b60);
      draw();
    },
    update(dt, g) {
      if (!game) return;
      if (building !== null) {
        building += dt;
        if (building >= frameTime || game.reducedMotion) {
          building = null;
          refresh();
          if (document.activeElement === document.body) focus(el('confirm'));
        }
      }
      if (world.trip === 'sailing') {
        crossing += dt;
        if (crossing >= tripTime || game.reducedMotion) arrive(false);
      }
      draw(g.time);
    }
  });
  if (closed) await player.dispose();
  else {
    game = player;
    el('sound').disabled = false;
    refresh();
  }
} catch (error) {
  if (!closed) {
    console.error(error);
    el('objective').textContent = '渡口暂时无法开启';
    el('hint').textContent = '请刷新页面，再试一次。';
  }
}
