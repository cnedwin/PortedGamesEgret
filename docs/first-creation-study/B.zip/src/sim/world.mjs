export const PLOTS = [
  { id: 'willow', name: '柳荫', x: 206, y: 337, note: '柳荫遮住了上岸的小路。' },
  { id: 'stone', name: '石阶', x: 353, y: 397, note: '从石阶走到泊位只需几步。' },
  { id: 'reed', name: '芦湾', x: 554, y: 479, note: '芦苇挡风，湾里水势平缓。' }
];
export const buildCost = 8;
export const firstFare = 3;
export const findPlot = id => PLOTS.find(plot => plot.id === id);

export function beginWorld(saved) {
  const shed = findPlot(saved?.shed) ?? null;
  const trip = shed && ['sailing', 'arrived'].includes(saved?.trip) ? saved.trip : 'waiting';
  return { selected: null, shed, trip };
}

export function buildShed(world) {
  if (world.shed || !world.selected) return false;
  world.shed = world.selected;
  world.selected = null;
  return true;
}

export function boardGuest(world) {
  if (!world.shed || world.trip !== 'waiting') return false;
  world.trip = 'sailing';
  return true;
}
