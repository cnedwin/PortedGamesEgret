const paper = 0xf8e5b5;
const dark = 0x37483b;

function shape(g, color, points, alpha = 1) {
  g.beginFill(color, alpha).moveTo(...points[0]);
  for (const point of points.slice(1)) g.lineTo(...point);
  g.lineTo(...points[0]).endFill();
}

function line(g, color, width, points, alpha = 1) {
  g.lineStyle(width, color, alpha).moveTo(...points[0]);
  for (const point of points.slice(1)) g.lineTo(...point);
  g.lineStyle();
}

function ellipse(g, color, x, y, w, h, alpha = 1) {
  g.beginFill(color, alpha).drawEllipse(x, y, w, h).endFill();
}

function tile(g, color, x, y, w, h) {
  g.beginFill(color).drawRect(x, y, w, h).endFill();
}

function ridge(g, color, points, floor, alpha = 1) {
  g.beginFill(color, alpha).moveTo(0, floor).lineTo(...points[0]);
  for (let i = 1; i < points.length; i++) {
    const [x, y] = points[i];
    const [px, py] = points[i - 1];
    g.curveTo(px + (x - px) * .46, py, px + (x - px) * .66, (py + y) / 2).curveTo(x - (x - px) * .18, y, x, y);
  }
  g.lineTo(960, floor).lineTo(0, floor).endFill();
}

function willow(g, x, y, s) {
  ellipse(g, 0x314537, x - s * .62, y - 5, s * 1.4, s * .22, .25);
  const p = (dx, dy) => [x + s * dx, y + s * dy];
  shape(g, 0x584834, [p(-.13, 0), p(-.07, -.53), p(-.19, -.89), p(-.08, -.93), p(.04, -.62), p(.28, -.92), p(.33, -.87), p(.08, -.47), p(.12, 0)]);
  const crowns = [[-.64, -.99, .66, .46], [-.34, -1.19, .8, .43], [.08, -1.03, .65, .45], [-.06, -.9, .69, .42], [-.79, -.82, .59, .32]];
  crowns.forEach(([dx, dy, w, h], i) => ellipse(g, [0x60765a, 0x778962, 0x526e55][i % 3], x + dx * s, y + dy * s, w * s, h * s));
  for (let i = 0; i < 19; i++) {
    const dx = -.72 + i * .075;
    const dy = -.76 - Math.sin(i * .21) * .15;
    line(g, i % 3 ? 0x8b9b6b : 0x425e48, Math.max(1, s / 54), [p(dx, dy), p(dx - .05, dy + .22), p(dx - .02, dy + .36 + .09 * Math.sin(i * 2))], .85);
  }
}

function house(g, x, y, w, h) {
  shape(g, 0x8d8b72, [[x - w / 2, y - h * .7], [x - w * .21, y - h], [x - w * .14, y], [x - w / 2, y]]);
  shape(g, 0xe7dbb6, [[x - w * .21, y - h], [x + w * .42, y - h], [x + w * .42, y], [x - w * .14, y]]);
  tile(g, 0x556053, x + w * .04, y - h * .51, w * .12, h * .51);
  tile(g, 0x7e8671, x + w * .25, y - h * .56, w * .1, h * .21);
  shape(g, 0x465b51, [[x - w * .58, y - h * .65], [x - w * .3, y - h * 1.27], [x + w * .26, y - h * 1.29], [x + w * .55, y - h * .79], [x + w * .23, y - h * .74], [x - w * .23, y - h * .77]]);
  line(g, 0x82917b, 1, [[x - w * .34, y - h * 1.28], [x + w * .25, y - h * 1.29], [x + w * .34, y - h * 1.34]]);
}

const bank = [[0, 276], [74, 267], [139, 282], [208, 302], [267, 315], [320, 338], [392, 357], [453, 377], [506, 409], [570, 441], [643, 461], [724, 483], [819, 510], [960, 527]];
const farBank = [[0, 223], [124, 216], [238, 231], [362, 228], [485, 213], [608, 201], [698, 201], [780, 184], [875, 191], [960, 176]];

export function terrain(game, plots) {
  game.sprite(g => {
    g.beginLinearGradientFill(0, 0, 0, 255, [{ offset: 0, color: 0xe2ddbd }, { offset: 1, color: 0xf3e9c8 }]).drawRect(0, 0, 960, 272).endFill();
    ellipse(g, 0xffedb3, 705, 29, 62, 62, .83);
    ridge(g, 0xb1bbb0, [[0, 110], [80, 84], [150, 102], [245, 43], [305, 65], [367, 112], [476, 86], [544, 115], [670, 70], [744, 98], [864, 48], [960, 94]], 219);
    ridge(g, 0x9eafa3, [[0, 152], [92, 118], [164, 139], [246, 91], [307, 124], [370, 150], [483, 122], [569, 156], [694, 116], [782, 143], [876, 105], [960, 141]], 225);
    ridge(g, 0x839a90, [[0, 170], [78, 149], [182, 180], [302, 148], [417, 177], [518, 155], [629, 179], [765, 137], [843, 165], [960, 130]], 233);
    ellipse(g, 0xf9eed5, -130, 145, 710, 34, .37);
    ellipse(g, 0xf9eed5, 428, 157, 684, 29, .39);
    g.beginLinearGradientFill(0, 212, 90, 540, [{ offset: 0, color: 0x8ba89b }, { offset: 1, color: 0x547e70 }]).drawRect(0, 173, 960, 367).endFill();
    for (let i = 0; i < 112; i++) {
      const x = (i * 187 + 47) % 960;
      const y = 187 + (i * 71) % 347;
      ellipse(g, i % 4 ? 0xd4dfc5 : 0x355e53, x, y, 9 + i * 9 % 61, i % 3 + 1, i % 5 ? .31 : .49);
    }
    shape(g, 0xa6b094, [[0, 189], [153, 180], [277, 198], [416, 200], [613, 173], [733, 165], [870, 163], [960, 148], ...farBank.slice().reverse()]);
    line(g, 0xe5dcc0, 5, farBank, .68);
    willow(g, 624, 198, 35);
    willow(g, 941, 175, 47);
    house(g, 680, 196, 47, 19);
    house(g, 723, 187, 56, 22);
    house(g, 771, 182, 44, 19);
    house(g, 868, 186, 63, 22);
    house(g, 913, 180, 34, 16);
    for (let i = 0; i < 6; i++) {
      const x = 790 + i * 6;
      line(g, 0x77745a, 1, [[x, 187], [x, 177]]);
    }
    line(g, 0x77745a, 1, [[788, 180], [824, 179]]);
    dock(g, [[814, 185], [832, 187], [822, 218], [798, 217]], 5);
    shape(g, 0x829473, [...bank, [960, 540], [0, 540]]);
    line(g, 0x426656, 10, bank);
    line(g, 0xbabe99, 3, bank.map(([x, y]) => [x, y - 3]));
    line(g, 0x9c9a74, 28, [[-5, 351], [97, 335], [208, 352], [323, 392], [399, 406], [454, 397], [502, 444], [573, 491], [663, 531], [710, 548]]);
    line(g, 0xd1bc8e, 20, [[-5, 352], [97, 335], [208, 352], [323, 392], [399, 406], [454, 397], [502, 444], [573, 491], [663, 531], [710, 548]]);
    dock(g, [[427, 395], [454, 401], [508, 349], [484, 343]], 8);
    for (let i = 0; i < 117; i++) {
      const x = (i * 73 + 3) % 740;
      const y = 285 + (i * 43) % 253;
      const j = bank.findIndex(point => point[0] >= x);
      const [lx, ly] = bank[j - 1];
      const [rx, ry] = bank[j];
      if (y < ly + (ry - ly) * (x - lx) / (rx - lx) + 3) continue;
      ellipse(g, i % 4 ? 0x526d55 : 0xe0cf9b, x, y, 3 + i % 9, 1 + i % 3, .58);
    }
    willow(g, 97, 355, 83);
    willow(g, 21, 491, 115);
    willow(g, 710, 532, 61);
    for (const [x, y] of [[24, 303], [143, 298], [284, 345], [315, 368], [457, 477], [619, 481], [655, 500], [138, 510], [309, 499]]) {
      reeds(g, x, y);
    }
    for (const plot of plots) {
      ellipse(g, 0x6c795b, plot.x - 42, plot.y - 8, 84, 19, .55);
      line(g, 0xf3dc9e, 1.5, [[plot.x - 38, plot.y], [plot.x - 17, plot.y - 7], [plot.x + 38, plot.y - 3], [plot.x + 22, plot.y + 8], [plot.x - 38, plot.y]], .85);
    }
  });
}

function reeds(g, x, y) {
  for (let i = 0; i < 10; i++) {
    const dx = (i - 4) * 2.5;
    const height = 7 + (i * 17) % 18;
    line(g, i % 3 ? 0x526f50 : 0xa8a367, 1.5, [[x + dx * .45, y], [x + dx, y - height * .65], [x + dx * 1.3, y - height]]);
    if (i % 3 === 0) ellipse(g, 0x7b653d, x + dx * 1.3 - 2, y - height - 3, 4, 5);
  }
}

function dock(g, corners, boards) {
  const [a, b, c, d] = corners;
  for (const [x, y] of corners) tile(g, 0x554c3b, x - 2, y - 4, 4, 12);
  shape(g, 0x9c7a54, corners);
  for (let i = 0; i < boards; i++) {
    const t = i / boards;
    line(g, 0xc6a577, 1, [[a[0] + (d[0] - a[0]) * t, a[1] + (d[1] - a[1]) * t], [b[0] + (c[0] - b[0]) * t, b[1] + (c[1] - b[1]) * t]]);
  }
  for (const [x, y] of [c, d]) tile(g, 0x64503a, x - 2, y - 8, 4, 10);
}

export function shedArt(game, stage) {
  return game.sprite(g => {
    const preview = stage === 'preview';
    const wood = preview ? 0xede2ac : 0x795337;
    const beam = preview ? 0xf9edbd : 0xb38554;
    ellipse(g, dark, -48, -9, 96, 23, .28);
    shape(g, wood, [[-43, -5], [-28, -14], [41, -13], [49, 1], [-31, 8]], .88);
    for (const [x, y] of [[-34, 0], [-22, -9], [32, 1], [43, -9]]) {
      tile(g, wood, x - 3, y - 44, 6, 44);
      tile(g, beam, x - 2, y - 43, 2, 42);
    }
    line(g, beam, 4, [[-38, -43], [31, -43], [44, -52], [-22, -52], [-38, -43]]);
    line(g, wood, 3, [[-33, -30], [-22, -42]]);
    line(g, wood, 3, [[20, -43], [31, -31]]);
    for (const x of [-28, -6, 16, 37]) line(g, beam, 3, [[x - 8, -43], [x + 10, -64], [x + 16, -50]]);
    if (stage === 'frame') return;
    const roof = preview ? 0xe6d3a0 : 0x3d584d;
    shape(g, roof, [[-52, -40], [-30, -56], [-13, -69], [50, -65], [42, -58], [54, -50], [33, -37], [-35, -37]], .96);
    for (let i = 0; i < 10; i++) {
      const x = -13 + i * 6;
      line(g, preview ? paper : 0x74907c, 1.4, [[x, -67 + i * .36], [x - 15, -50], [x - 26, -39]], .85);
    }
    line(g, beam, 2, [[-15, -69], [49, -65], [54, -69]]);
    if (preview) return;
    line(g, 0xa28452, 2, [[-7, -37], [-7, -31]]);
    ellipse(g, 0xffd592, -19, -36, 24, 27, .19);
    tile(g, 0xd67b47, -13, -30, 12, 14);
    tile(g, 0xf8c778, -10, -28, 6, 10);
    tile(g, dark, -14, -31, 14, 2);
    tile(g, dark, -14, -17, 14, 2);
    line(g, 0x845d3e, 3, [[11, -3], [24, -26]]);
  });
}

export function personArt(game, coat, hat) {
  return game.sprite(g => {
    ellipse(g, 0x304f43, -9, -3, 18, 6, .34);
    line(g, dark, 2.6, [[-4, -8], [-4, -1], [-6, 0]]);
    line(g, dark, 2.6, [[3, -8], [4, 0], [7, 0]]);
    shape(g, coat, [[-5, -21], [5, -21], [8, -7], [-7, -7]]);
    line(g, dark, 1.4, [[-5, -10], [5, -10]], .75);
    ellipse(g, 0xd6ae81, -4, -28, 9, 10);
    shape(g, hat, [[-11, -25], [-5, -29], [1, -33], [8, -28], [12, -25]]);
    line(g, 0xf2d298, 1, [[-9, -25], [11, -25]]);
  });
}

export function boatArt(game) {
  const wake = game.sprite(g => {
    line(g, 0xdfebcd, 2, [[-84, 20], [-55, 16], [-35, 11]], .6);
    line(g, 0xc4d7b9, 1.5, [[-111, 9], [-70, 11], [-43, 7]], .55);
    line(g, 0xe9e7c8, 1, [[-52, 22], [-42, 19], [-24, 17]], .7);
  });
  const boat = game.sprite(g => {
    ellipse(g, 0x2d6055, -59, 0, 117, 16, .38);
    shape(g, 0x594b35, [[-57, -11], [-39, -5], [34, -5], [57, -12], [46, 2], [31, 8], [-34, 8], [-47, 1]]);
    line(g, 0xd3ad70, 2, [[-56, -11], [-26, -7], [30, -7], [56, -12]]);
    line(g, 0x897151, 1, [[-40, 2], [37, 2]]);
    g.beginFill(0x3e5547).moveTo(-23, -7).lineTo(-23, -13).curveTo(-19, -34, -4, -34).curveTo(18, -36, 26, -14).lineTo(26, -7).endFill();
    g.lineStyle(2, 0xc4aa77).moveTo(-22, -8).curveTo(-19, -33, -3, -33).curveTo(16, -34, 25, -10).lineStyle();
    line(g, 0x6e836c, 1, [[-16, -17], [17, -17]]);
    line(g, 0x6e836c, 1, [[-13, -22], [14, -22]]);
    line(g, 0x6e836c, 1, [[-8, -27], [10, -27]]);
  });
  return { boat, wake };
}
