export const SAVE_KEY = 'mist-ferry';
const RECORD = 'first-crossing-v1';
export const readProgress = game => game.load(RECORD, null);

export function writeProgress(game, world, muted) {
  game.save(RECORD, { shed: world.shed?.id ?? null, trip: world.trip, muted });
}
