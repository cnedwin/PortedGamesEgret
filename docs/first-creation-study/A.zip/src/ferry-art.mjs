import { Sprite } from '@egret/engine';

function path(g, points) {
  g.moveTo(...points[0]);
  for (const point of points.slice(1)) {
    if (point.length === 4) g.curveTo(...point);
    else g.lineTo(...point);
  }
}
function fill(g, color, points, alpha = 1) {
  g.lineStyle(0).beginFill(color, alpha);
  path(g, points);
  g.lineTo(...points[0]).endFill();
}
function line(g, color, width, points, alpha = 1) {
  g.lineStyle(width, color, alpha);
  path(g, points);
  g.lineStyle(0);
}
function oval(g, color, x, y, w, h, alpha = 1) {
  g.lineStyle(0).beginFill(color, alpha).drawEllipse(x, y, w, h).endFill();
}
function box(g, color, x, y, w, h, alpha = 1) {
  g.lineStyle(0).beginFill(color, alpha).drawRect(x, y, w, h).endFill();
}
function wash(g, y, h, top, bottom) {
  g.beginLinearGradientFill(0, y, 0, y + h, [{ offset: 0, color: top }, { offset: 1, color: bottom }]).drawRect(0, y, 960, h).endFill();
}
function roof(g, x, y, w, h, color) {
  fill(g, color, [[x - 8, y + h], [x + w * .18, y + h * .75, x + w * .40, y], [x + w * .60, y - 2], [x + w * .83, y + h * .78, x + w + 7, y + h], [x + w * .57, y + h + 9, x - 8, y + h]]);
  line(g, 0x243e3a, 2, [[x - 9, y + h - 1], [x + w * .48, y + h + 8, x + w + 8, y + h]]);
  for (let i = 1; i < 8; i++) {
    const at = i / 8;
    line(g, 0xd4d6aa, 1, [[x + w * (.4 + at * .2), y + 1], [x + w * at, y + h + 2]], .25);
  }
}
function house(g, x, feet, w, h, tone) {
  const y = feet - h;
  fill(g, tone, [[x, y], [x + w, y - 4], [x + w, feet], [x, feet + 2]]);
  fill(g, 0xadb5a1, [[x + w * .80, y], [x + w, y - 4], [x + w, feet], [x + w * .80, feet]]);
  box(g, 0x687971, x, feet - 4, w, 4);
  box(g, 0x55655b, x + w * .42, feet - h * .44, w * .16, h * .44);
  for (const offset of [.17, .68]) {
    box(g, 0x65746a, x + w * offset, y + h * .38, w * .1, h * .16);
    line(g, tone, 1, [[x + w * (offset + .05), y + h * .38], [x + w * (offset + .05), y + h * .54]]);
  }
  roof(g, x, y - h * .43, w, h * .51, 0x4d635e);
}
function tree(g, x, y, s, near = false) {
  const c = near ? 0x554f39 : 0x657668;
  line(g, c, 6 * s, [[x, y], [x - 11 * s, y - 43 * s, x + 1 * s, y - 82 * s]]);
  for (const [dx, dy] of [[-37, -70], [33, -89], [-12, -110], [50, -63]]) {
    line(g, c, 3 * s, [[x - 5 * s, y - 28 * s], [x + dx * .3 * s, y - 55 * s, x + dx * s, y + dy * s]]);
  }
  const colors = near ? [0x415f4b, 0x587357, 0x738b62, 0x8e9b65] : [0x788d78, 0x8d9d84, 0x9da98a, 0xa9b096];
  for (const [dx, dy, w, h, i] of [[-67,-83,65,26,0],[-58,-96,69,26,1],[-32,-117,79,31,0],[-23,-126,67,25,2],[5,-101,82,31,1],[14,-110,67,23,2],[20,-81,70,27,0],[31,-90,61,24,1],[-58,-105,26,12,3],[-7,-122,31,12,3],[42,-105,24,11,3],[52,-87,29,13,2]]) {
    oval(g, colors[i], x + dx * s, y + dy * s, w * s, h * s);
  }
  if (near) {
    for (let i = 0; i < 13; i++) {
      const dx = -50 + i * 10;
      line(g, 0x677e53, 1.4 * s, [[x + dx * s, y - (78 + Math.sin(i) * 10) * s], [x + (dx + 8) * s, y - 62 * s, x + (dx + 1) * s, y - (34 + i % 4 * 6) * s]], .74);
    }
  }
}
function reeds(g, x, y, s) {
  for (let i = 0; i < 9; i++) {
    const dx = (i - 4) * 4 * s, h = (26 + (i * 7) % 19) * s;
    line(g, i % 2 ? 0x7b834d : 0x5e754f, 1.4, [[x + dx * .28, y], [x + dx * .4, y - h * .7, x + dx, y - h]]);
    line(g, 0x788650, 2, [[x + dx * .3, y - h * .2], [x - dx * .25, y - h * .43, x - dx * .73, y - h * .52]]);
    oval(g, 0xaa8d54, x + dx - 2 * s, y - h - 7 * s, 4 * s, 9 * s);
  }
}
function figure(g, coat, hat, basket = false) {
  oval(g, 0x3b4939, -13, -4, 26, 8, .25);
  box(g, 0x3d4641, -6, -9, 4, 9);
  box(g, 0x3d4641, 3, -9, 4, 9);
  fill(g, coat, [[-6,-29],[6,-29],[11,-7],[4,-4],[-10,-7]]);
  line(g, 0xffe2b5, 1, [[2,-27],[-1,-20],[-1,-8]], .55);
  oval(g, 0xd9aa7c, -6, -40, 13, 14);
  fill(g, hat, [[-12,-37],[0,-49],[12,-37],[1,-34]]);
  line(g, 0x604b39, 1, [[-12,-37],[1,-34],[12,-37]]);
  if (basket) {
    line(g, 0x754b31, 2, [[7,-15],[11,-26,17,-15]]);
    fill(g, 0xb1834f, [[5,-16],[19,-16],[16,-7],[8,-7]]);
    line(g, 0x7d5837, 1, [[7,-13],[18,-13]]);
  }
}

export function paintFerry(game) {
  const make = () => game.stage.addChild(game.scope.use(new Sprite()));
  const terrain = make().graphics;
  let seed = 89;
  const random = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296);
  const g = terrain;
  wash(g, 0, 259, 0xeee6cb, 0xe5e7cc);
  oval(g, 0xfaf0c9, 681, 35, 127, 109, .38);
  oval(g, 0xfbf0c9, 714, 56, 60, 60, .87);
  fill(g, 0xb5c1aa, [[0,117],[58,72,122,119],[173,164,223,126],[294,49,348,100],[381,123,421,145],[481,176,524,101],[579,32,622,91],[658,139,706,115],[770,56,815,105],[896,114,960,73],[960,233],[0,233]]);
  fill(g, 0x97af9e, [[0,156],[62,110,130,162],[200,190,247,156],[305,103,354,154],[429,197,485,150],[563,105,621,160],[689,195,751,132],[831,99,875,146],[921,172,960,144],[960,234],[0,234]]);
  fill(g, 0x7e9b8a, [[0,180],[87,148,158,190],[214,218,291,187],[335,163,401,195],[454,213,521,183],[593,139,654,192],[723,219,794,168],[860,151,960,186],[960,239],[0,239]]);
  oval(g, 0xf5efd7, -94, 149, 677, 35, .57);
  oval(g, 0xf5efd7, 458, 175, 488, 29, .45);
  wash(g, 225, 345, 0xb4c8b6, 0x749d97);
  fill(g, 0x9cb1a1, [[0,226],[199,221,439,226],[399,247,277,260],[161,254,0,284]]);
  for (let i = 0; i < 173; i++) {
    const x = random() * 960, t = random(), y = 233 + t * t * 334;
    const w = 7 + random() * (26 + t * 76);
    line(g, i % 4 ? 0xeef0d7 : 0x507d76, .65 + t * 1.3, [[x,y],[x + w * .45,y - 2,x + w,y]], .10 + random() * .31);
  }
  fill(g, 0x778d78, [[0,216],[118,211,179,227],[243,221,294,227],[383,218,433,228],[394,246,310,243],[159,253,69,241],[0,247]]);
  for (const [x,y,s] of [[23,230,.63],[95,221,.40],[186,235,.49],[253,231,.53],[371,229,.59],[412,228,.39]]) tree(g,x,y,s);
  for (const [x,y,w,h,c] of [[14,235,51,30,0xe6e4cf],[69,237,68,49,0xf2ead1],[135,241,44,28,0xdcdcc4],[188,230,51,35,0xf4ecd4],[244,242,67,47,0xeee7d1],[316,237,53,31,0xf4e9cc],[367,231,35,23,0xd9e0c8]]) house(g,x,y,w,h,c);
  for (let i = 0; i < 30; i++) {
    const x = i * 14 - 7, y = 244 + Math.sin(i * .52) * 4;
    oval(g, i % 3 ? 0x869485 : 0xb1b5a0, x, y, 18, 5, .85);
  }
  fill(g, 0x7e8d80, [[180,242],[221,241],[209,266],[174,265]]);
  for (let i = 0; i < 4; i++) line(g,0xc1c0a8,2,[[181-i*2,248+i*5],[218-i*3,247+i*5]]);
  for (const [x,y,s] of [[454,239,.22],[475,239,.24],[903,231,.24]]) tree(g,x,y,s);
  oval(g, 0xf5eed4, 315, 214, 314, 23, .22);
  for (const [x,y,s] of [[504,117,1],[529,109,.72],[544,124,.60]]) line(g,0x617d70,1.2,[[x-8*s,y],[x-4*s,y-5*s,x,y],[x+4*s,y-5*s,x+8*s,y]],.8);

  fill(g, 0x668d7f, [[960,256],[870,242,801,263],[697,269,665,313],[625,375,603,404],[590,444,551,479],[517,517,488,570],[960,570]]);
  fill(g, 0x8a9170, [[960,258],[875,246,804,270],[706,273,671,317],[637,374,617,407],[601,449,559,484],[527,523,503,570],[960,570]]);
  fill(g, 0xb0a67b, [[960,265],[864,254,815,277],[740,282,687,320],[659,350,632,414],[621,455,579,490],[547,529,522,570],[960,570]]);
  fill(g, 0xc8b28a, [[960,293],[871,271,810,306],[727,337,685,383],[657,422,667,453],[696,479,614,518],[582,542,577,570],[760,570],[733,544,776,502],[854,451,806,406],[803,371,863,343],[918,320,960,337]]);
  fill(g, 0x9c9d70, [[960,400],[914,376,870,403],[825,421,852,469],[875,509,797,538],[769,550,771,570],[960,570]]);
  for (let i = 0; i < 150; i++) {
    const y = 292 + random() * 278;
    const edge = 830 - (y - 292) * 1.03;
    const x = edge + random() * (960 - edge);
    const w = 1 + random() * 10;
    oval(g, i % 3 ? 0x756f52 : 0xf4d7a3, x, y, w, 1 + random() * 3, .14 + random() * .25);
  }
  for (const [x,y,w] of [[688,319,18],[665,348,16],[653,375,14],[624,432,15],[583,476,21],[555,502,12],[531,541,26],[522,553,19],[793,285,13],[809,283,15]]) {
    fill(g, 0x818879, [[x-w,y+4],[x-w*.7,y-2],[x+2,y-5],[x+w*.48,y-1],[x+w*.6,y+5],[x,y+8]]);
    line(g, 0xb8bea6, 1.4, [[x-w*.7,y-2],[x+2,y-5],[x+w*.48,y-1]]);
  }
  for (const [x,y,s] of [[804,296,.48],[912,321,.9],[952,332,.67],[879,523,1.15],[749,530,.86],[550,557,.86],[567,544,.65],[683,355,.49]]) reeds(g,x,y,s);
  oval(g, 0x607154, 815, 278, 164, 33, .29);
  tree(g, 877, 293, 1.42, true);
  tree(g, 939, 292, .86, true);

  // Timber landing, mooring posts and lantern.
  fill(g, 0x42645d, [[457,389],[660,421],[632,451],[446,412]], .32);
  for (const [x,y] of [[461,386],[483,402],[537,395],[556,414],[603,405],[623,427]]) box(g,0x615542,x-3,y-3,6,25);
  fill(g, 0x82674d, [[451,371],[672,408],[643,432],[449,400]]);
  fill(g, 0xbe9a70, [[451,367],[672,404],[643,426],[449,394]]);
  for (let i = 0; i < 18; i++) {
    const t = i / 18;
    line(g, 0x806449, 1, [[451+t*221,367+t*37],[449+t*194,394+t*32]], .76);
    line(g, 0xe4be88, 1, [[453+t*221,368+t*37],[451+t*194,394+t*32]], .7);
  }
  for (const [x,y] of [[454,370],[451,393],[548,387],[544,407],[639,420]]) {
    box(g,0x68543c,x-3,y-15,6,19);
    oval(g,0xc6a173,x-3,y-17,6,4);
  }
  box(g,0x6a5940,669,390,5,28);
  box(g,0x6a5940,658,392,14,3);
  box(g,0xa65437,658,397,9,13);
  box(g,0xe7b86f,660,400,5,7);

  const plot = make();
  const pg = plot.graphics;
  fill(pg, 0xbca986, [[688,367],[755,344],[818,369],[763,398]]);
  const corners = [[688,367],[755,344],[818,369],[763,398]];
  line(pg,0xf6e1ac,2,[...corners,corners[0]]);
  for (const [x,y] of corners) {
    box(pg,0x775d41,x-2,y-12,4,15);
    box(pg,0xd4a977,x-2,y-12,4,3);
  }
  const shed = make();
  const sh = shed.graphics;
  oval(sh,0x5b664e,690,366,135,28,.32);
  fill(sh,0x917455,[[689,358],[754,343],[816,364],[768,391],[689,379]]);
  fill(sh,0xc0a078,[[691,353],[755,339],[818,361],[768,384],[691,374]]);
  for (const [x,y,h] of [[710,358,61],[782,353,59],[805,366,49],[703,371,52],[767,382,58]]) {
    box(sh,0x66513c,x-3,y-h,6,h);
    box(sh,0xa27b52,x-2,y-h,2,h);
  }
  fill(sh,0x796347,[[712,323],[781,311],[781,350],[712,365]]);
  for (let i = 0; i < 10; i++) line(sh,0xa58b61,1,[[716+i*7,323-i],[716+i*7,361-i*1.1]]);
  fill(sh,0xa48759,[[721,277],[765,262],[813,301],[804,332],[744,316]]);
  fill(sh,0xc3a06a,[[678,326],[697,307,721,277],[766,288],[787,325,823,333],[759,347],[718,341,678,326]]);
  for (let i = 0; i < 15; i++) {
    const t = i / 14;
    line(sh, i % 2 ? 0xe0be81 : 0x937648, 1.4, [[721+45*t,278+10*t],[708+48*t,311+7*t,682+137*t,326+12*t]], .83);
  }
  line(sh,0x66543a,3,[[678,326],[718,341,759,347],[823,333]]);
  box(sh,0x36574a,742,340,23,12);
  line(sh,0xd6bb81,1,[[746,346],[761,346]]);
  box(sh,0xab4d35,772,345,8,13);
  box(sh,0xf0c372,774,348,4,7);

  const wood = make();
  for (const [x,y] of [[825,472],[841,480],[854,471],[838,463],[851,459]]) {
    fill(wood.graphics,0x8d6546,[[x-12,y],[x+22,y-18],[x+28,y-12],[x-4,y+6]]);
    line(wood.graphics,0xc09768,1.2,[[x-7,y],[x+24,y-16]]);
    oval(wood.graphics,0xc29b70,x-13,y-1,11,9);
    oval(wood.graphics,0x9a734e,x-10,y+1,5,5);
  }
  const grasses = make();
  for (const [x,y,s] of [[582,536,1.05],[603,530,1.16],[622,539,.84]]) reeds(grasses.graphics,x,y,s);
  for (const [x,y] of [[603,459],[513,507],[455,484]]) {
    oval(g,0x587f69,x,y,22,6,.7);
    oval(g,0x8b9e68,x+12,y+7,15,5,.8);
  }

  const ashore = make();
  ashore.x = 648;
  ashore.y = 413;
  figure(ashore.graphics,0x9e5843,0x8a704f,true);
  const wake = make();
  for (let i = 0; i < 4; i++) line(wake.graphics,0xf2ecd1,1.4,[[15+i*9,9+i*4],[62+i*4,14+i*4,110+i*10,11+i*4]],.49-i*.08);
  const boat = make();
  const b = boat.graphics;
  oval(b,0x456e66,-82,10,167,19,.32);
  fill(b,0x4d4234,[[-90,-10],[-46,4],[50,5],[89,-13],[65,11,51,16],[-54,19],[-74,15,-90,-10]]);
  fill(b,0x8c6547,[[-89,-10],[-45,0],[47,0],[89,-13],[62,7,47,9],[-50,11],[-75,8,-89,-10]]);
  line(b,0xd4a374,2,[[-89,-10],[-25,7,25,3],[61,1,89,-13]]);
  fill(b,0x374944,[[-46,0],[-44,-33,-24,-39],[20,-40],[38,-36,49,-3],[10,2],[-46,0]]);
  for (let i = 0; i < 8; i++) {
    const x = -34+i*9;
    line(b,0x91a18a,1,[[x+7,-38],[x-6,-28,x-6,0]],.6);
  }
  line(b,0xc49c66,2,[[-46,-2],[-46,-29,-26,-38]]);
  const ferryPerson = boat.addChild(game.scope.use(new Sprite()));
  ferryPerson.x = -57;
  ferryPerson.y = 3;
  ferryPerson.scaleX = ferryPerson.scaleY = .84;
  figure(ferryPerson.graphics,0x466e61,0xc2a065);
  const oar = boat.addChild(game.scope.use(new Sprite()));
  oar.x = -58;
  oar.y = -14;
  line(oar.graphics,0xaa8760,3,[[8,-12],[-28,31]]);
  line(oar.graphics,0x826342,5,[[-28,31],[-34,37]]);
  const aboard = boat.addChild(game.scope.use(new Sprite()));
  aboard.x = 49;
  aboard.y = 4;
  aboard.scaleX = aboard.scaleY = .64;
  figure(aboard.graphics,0x9e5843,0x8a704f,true);
  const landed = make();
  landed.x = 200;
  landed.y = 255;
  landed.scaleX = landed.scaleY = .64;
  figure(landed.graphics,0x9e5843,0x8a704f,true);

  return (state, travel, time) => {
    plot.visible = state.phase === 0;
    shed.visible = state.phase > 0;
    wood.visible = !state.wood;
    grasses.visible = !state.reed;
    ashore.visible = state.phase <= 1;
    aboard.visible = state.phase === 2 || state.phase === 3;
    landed.visible = state.phase === 4;
    const t = travel * travel * (3 - 2 * travel);
    boat.scaleX = boat.scaleY = 1 - .37 * t;
    boat.x = 417 - 226 * t;
    boat.y = 420 - 139 * t + Math.sin(time * 1.8) * 1.4;
    boat.rotation = -5 * Math.sin(t * Math.PI);
    oar.rotation = state.phase === 3 ? Math.sin(time * 7) * 15 : 0;
    wake.x = boat.x;
    wake.y = boat.y;
    wake.visible = state.phase === 3;
  };
}
