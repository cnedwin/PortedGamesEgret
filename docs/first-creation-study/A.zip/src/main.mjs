import { createBrowserGame } from '@egret/engine/web/game';
import { createSound } from './audio/sound.mjs';
import { paintFerry } from './ferry-art.mjs';

const host = document.querySelector('#frame');
host.innerHTML = `
<header class="mast"><div class="wrap">
  <div class="brand"><span class="mark" aria-hidden="true"></span><div><strong>雾汀渡</strong><small>江南渡口经营小记</small></div></div>
  <div class="tools"><button class="quiet" id="sound" type="button" aria-pressed="false">声音关闭</button><button class="quiet" id="help" type="button">渡口指南</button></div>
</div></header>
<div class="wrap">
  <section class="heading" aria-labelledby="chapter">
    <div><p class="eyebrow">第一章 · 初到雾汀</p><h1 id="chapter">开渡第一日</h1><p class="intro">晨雾将散，先给摆渡人搭一座船棚。</p></div>
    <div class="stock" aria-label="渡口物资"><span><i class="symbol wood" aria-hidden="true"></i>木料<b id="wood"></b></span><span><i class="symbol reed" aria-hidden="true"></i>芦苇<b id="reed"></b></span><span><i class="symbol coin" aria-hidden="true"></i>铜钱<b id="cash"></b></span></div>
  </section>
  <div class="grid">
    <section class="scene" aria-label="雾汀渡实景">
      <div class="map">
        <div id="landscape" aria-hidden="true"><canvas id="stage"></canvas></div>
        <span class="map-label"><i></i>南岸 · 雾汀渡</span>
        <button type="button" class="hot logs" data-gather="wood">取木料</button>
        <button type="button" class="hot grass" data-gather="reed">割芦苇</button>
        <button type="button" class="hot site" id="site" hidden>搭船棚</button>
        <button type="button" class="hot guest" id="guest" hidden>请上船</button>
      </div>
      <div class="scene-foot"><b id="shore"></b><span id="served"></span></div>
    </section>
    <aside class="panel" aria-labelledby="ledger">
      <div class="panel-top"><h2 id="ledger">渡口手记</h2><span class="folio" id="progress"></span></div>
      <ol class="steps"><li><i aria-hidden="true">1</i>备齐材料</li><li><i aria-hidden="true">2</i>搭起船棚</li><li><i aria-hidden="true">3</i>迎客过河</li></ol>
      <div class="task"><strong id="task-title"></strong><p id="task-copy" aria-live="polite"></p>
        <div class="gathers" id="gathers"><button class="gather" type="button" data-gather="wood">取木料 ＋2</button><button class="gather" type="button" data-gather="reed">割芦苇 ＋2</button></div>
      </div>
      <button class="primary" type="button" id="advance"></button>
      <p class="keys" id="keys"></p>
    </aside>
  </div>
  <div class="log"><strong><i class="dot"></i>开渡札记</strong><p id="log" role="status"></p></div>
</div>
<dialog id="guide"><h2>渡口指南</h2><p>点击岸边的木料和芦苇，或用右侧按钮收集。备齐三份木料和两份芦苇后，即可在码头旁搭船棚。棚成后，招呼沈阿婆登船，再撑船把她送到对岸。</p><p>键盘可按 1 取木、2 割苇，按 E 执行当前主操作。</p><form method="dialog"><button class="primary">回到渡口</button></form></dialog>`;

const $ = (id) => document.getElementById(id);
const key = 'wuting-first-ferry-v1';
function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(key));
    if (saved && [0, 1, 2, 4].includes(saved.phase) && typeof saved.wood === 'boolean' && typeof saved.reed === 'boolean' && (saved.phase === 0 || (saved.wood && saved.reed))) return saved;
  } catch { /* Storage is optional. */ }
  return { phase: 0, wood: false, reed: false };
}
let state = load();
let crossing = state.phase === 4 ? 1 : 0;
let game;
let sound;
let soundOn = false;
let soundLoading;
const advance = $('advance');
const gatherButtons = [...host.querySelectorAll('[data-gather]')];
const steps = [...host.querySelectorAll('.steps li')];
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const views = [
  ['备齐船棚用料', '搭棚要用木料 3 份、芦苇 2 份。', '搭起船棚', '码头待修'],
  ['沈阿婆在等船', '她提着一篮青菜，要到对岸的白墙村赶早市。', '迎客上船', '船棚已落成'],
  ['客人已坐稳', '沈阿婆坐在船篷下，沿水路送她去对岸。', '撑船过河', '乌篷船待发'],
  ['乌篷船过河中', '船正往白墙村的石阶靠拢。', '正在渡河', '渡船在途'],
  ['首渡顺利', '沈阿婆已到白墙村，付了 6 枚铜钱。', '重玩第一日', '今日首渡完成']
];
function ready() { return state.wood && state.reed; }
function render(note) {
  const phase = state.phase;
  const [title, copy, action, shore] = views[phase];
  const done = phase === 0 ? Number(ready()) : phase === 4 ? 3 : 2;
  $('wood').textContent = phase ? 0 : state.wood ? 3 : 1;
  $('reed').textContent = phase ? 0 : state.reed ? 2 : 0;
  $('cash').textContent = phase === 4 ? 6 : 0;
  $('shore').textContent = shore;
  $('served').textContent = `已渡客人 ${phase === 4 ? 1 : 0} / 1`;
  $('progress').textContent = phase === 4 ? '已开渡' : `${done} / 3`;
  $('task-title').textContent = phase === 0 && ready() ? '材料已经备齐' : title;
  $('task-copy').textContent = phase === 0 && ready() ? '码头边的地基已经划好，可以搭棚了。' : copy;
  advance.textContent = action;
  advance.disabled = phase === 3 || (phase === 0 && !ready());
  $('gathers').hidden = phase !== 0;
  $('site').hidden = phase !== 0 || !ready();
  $('guest').hidden = phase !== 1;
  for (const button of gatherButtons) {
    const has = state[button.dataset.gather];
    button.disabled = has || phase !== 0;
    if (button.classList.contains('hot')) button.hidden = button.disabled;
    else button.textContent = button.dataset.gather === 'wood' ? (has ? '木料已取' : '取木料 ＋2') : (has ? '芦苇已割' : '割芦苇 ＋2');
  }
  steps.forEach((item, index) => {
    item.classList.toggle('done', index < done);
    item.firstElementChild.textContent = index < done ? '✓' : index + 1;
    if (index === done) item.setAttribute('aria-current', 'step');
    else item.removeAttribute('aria-current');
  });
  $('keys').textContent = phase === 0 && !ready() ? '按 1 取木 · 按 2 割苇' : phase === 3 ? '' : '按 E 执行当前操作';
  $('log').textContent = note ?? ['摆渡人已系好乌篷船，正等岸上的船棚开工。', '船棚已经搭好，沈阿婆在码头等候。', '沈阿婆已登船，等着开渡。', '船离开南岸，驶向白墙村。', '沈阿婆提着菜篮上岸，雾汀渡迎来了第一笔船钱。'][phase];
}
function save() {
  try { localStorage.setItem(key, JSON.stringify(state)); } catch { /* The current day stays playable. */ }
}
function play(name) { if (soundOn) sound?.play(name); }
function collect(resource) {
  if (state.phase !== 0 || state[resource]) return;
  const focused = document.activeElement?.dataset.gather;
  state[resource] = true;
  save();
  play('light');
  render(resource === 'wood' ? '从岸边取来两份木料。' : '从水边割来两束芦苇。');
  if (focused) (ready() ? advance : gatherButtons.find((button) => button.classList.contains('gather') && !button.disabled))?.focus({ preventScroll: true });
}
function arrive() {
  crossing = 1;
  state.phase = 4;
  save();
  play('done');
  render();
}
function act() {
  if (advance.disabled) return;
  if (state.phase === 4) {
    state = { phase: 0, wood: false, reed: false };
    crossing = 0;
  } else {
    state.phase++;
    play(state.phase === 1 ? 'done' : 'tap');
    if (state.phase === 3 && (!game || reduced.matches)) {
      arrive();
      return;
    }
  }
  if (state.phase !== 3) save();
  render();
  if (state.phase === 0) gatherButtons.find((button) => button.classList.contains('gather')).focus({ preventScroll: true });
  if (state.phase === 1 || state.phase === 2) advance.focus({ preventScroll: true });
}
for (const button of gatherButtons) button.addEventListener('click', () => collect(button.dataset.gather));
for (const button of [advance, $('site'), $('guest')]) button.addEventListener('click', act);
$('help').addEventListener('click', () => $('guide').showModal());
$('sound').addEventListener('click', () => {
  soundOn = !soundOn;
  $('sound').textContent = soundOn ? '声音开启' : '声音关闭';
  $('sound').setAttribute('aria-pressed', String(soundOn));
  if (soundOn && game && !soundLoading) {
    soundLoading = createSound(game.scope).then((made) => { sound = made; play('tap'); }).catch(() => { soundLoading = null; });
  } else play('tap');
});
document.addEventListener('keydown', (event) => {
  if (event.repeat || event.ctrlKey || event.altKey || event.metaKey || $('guide').open) return;
  if (event.key === '1') collect('wood');
  if (event.key === '2') collect('reed');
  if (event.key.toLowerCase() === 'e') act();
});
render();

let redraw;
let time = 0;
try {
  game = await createBrowserGame({
    canvas: $('stage'), width: 960, height: 570, backend: 'webgl2', fit: 'contain', fitTo: $('landscape'),
    clearColor: 0xe6e3ca, autoStart: false,
    update(seconds) {
      const dt = Math.min(seconds, 0.06);
      if (!reduced.matches) time += dt;
      if (state.phase === 3) {
        crossing += dt / 3.2;
        if (crossing >= 1 || reduced.matches) arrive();
      }
      redraw?.(state, crossing, time);
    }
  });
  redraw = paintFerry(game);
  redraw(state, crossing, time);
  game.loop.start();
} catch {
  game = null;
  $('stage').hidden = true;
  $('log').textContent = '渡口画面暂时无法显示，可通过渡口手记完成开渡。';
}
